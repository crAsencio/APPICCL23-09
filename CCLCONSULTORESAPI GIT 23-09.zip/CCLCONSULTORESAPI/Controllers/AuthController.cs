﻿using CCLApi.Data;
using CCLApi.Models;
using CCLApi.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CCLApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly AuthService _authService;
        private readonly AppDbContext _context;

        public AuthController(AuthService authService, AppDbContext context)
        {
            _authService = authService;
            _context = context;
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] User user)
        {
            var dbUser = await GetUserFromDatabaseAsync(user.Username);

            if (dbUser == null)
            {
                return Unauthorized("Usuario no encontrado");
            }

            if (dbUser.Password == user.Password)
            {
                if (dbUser.MustChangePassword)
                {
                    return Ok(new { Message = "Debe cambiar su clave", Token = _authService.GenerateJwtToken(dbUser) });
                }

                var token = _authService.GenerateJwtToken(dbUser);
                return Ok(new { Token = token });
            }

            return Unauthorized("Contraseña incorrecta");
        }

        [HttpPost("validate-token")]
        public IActionResult ValidateToken([FromBody] string token)
        {
            bool isValid = _authService.ValidateJwtToken(token);
            if (isValid)
            {
                return Ok(new { Message = "Token válido" });
            }
            return Unauthorized("Token inválido");
        }

        private async Task<User> GetUserFromDatabaseAsync(string username)
        {
            return await _context.Users.FirstOrDefaultAsync(u => u.Username == username);
        }
    }
}
