﻿using CCLApi.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CCLApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class IvaController : ControllerBase
    {
        private readonly AppDbContext _context;

        public IvaController(AppDbContext context)
        {
            _context = context;
        }

        // Endpoint para obtener la tasa de IVA de un usuario específico (por UserId)
        [HttpGet("tasa/{userId}")]
        public async Task<IActionResult> ObtenerTasaPorUsuario(int userId)
        {
            // Filtrar en la base de datos por el ID del usuario
            var iva = await _context.Ivas.FirstOrDefaultAsync(i => i.UserId == userId);

            if (iva == null)
            {
                return NotFound("No se encontró la tasa de IVA para este usuario");
            }

            return Ok(new { Tasa = iva.Tasa });
        }

        // Opción alternativa: Filtrar por nombre de usuario
        [HttpGet("tasa/usuario/{username}")]
        public async Task<IActionResult> ObtenerTasaPorNombreUsuario(string username)
        {
            // Busca al usuario por el nombre de usuario
            var usuario = await _context.Users.FirstOrDefaultAsync(u => u.Username == username);
            if (usuario == null)
            {
                return NotFound("Usuario no encontrado");
            }

            // Luego busca la tasa de IVA asociada al usuario
            var iva = await _context.Ivas.FirstOrDefaultAsync(i => i.UserId == usuario.Id);
            if (iva == null)
            {
                return NotFound("No se encontró la tasa de IVA para este usuario");
            }

            return Ok(new { Tasa = iva.Tasa });
        }
    }
}
