﻿namespace CCLApi.Models
{
    public class Iva
    {
        public int Id { get; set; }
        public decimal Tasa { get; set; }
        public int UserId { get; set; }  // Relación con usuario
        public User User { get; set; }  // Navegación del usuario
    }
}
