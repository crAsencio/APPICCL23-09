﻿using CCLApi.Models;
using Microsoft.EntityFrameworkCore;

namespace CCLApi.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {
        }

        public DbSet<FinancialReport> FinancialReports { get; set; }
        public DbSet<User> Users { get; set; }
        public DbSet<Iva> Ivas { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<FinancialReport>().ToTable("FinancialReports");
            modelBuilder.Entity<User>().ToTable("Users");
            modelBuilder.Entity<Iva>().ToTable("Ivas");
        }
    }
}
