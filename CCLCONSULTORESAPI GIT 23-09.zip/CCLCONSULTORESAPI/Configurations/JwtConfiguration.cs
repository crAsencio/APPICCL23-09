﻿namespace CCLApi.Configurations
{
    public class JwtConfiguration
    {
        // Propiedades requeridas para la configuración del JWT
        public required string Secret { get; set; }
        public required string Issuer { get; set; }
        public required string Audience { get; set; }
    }
}
